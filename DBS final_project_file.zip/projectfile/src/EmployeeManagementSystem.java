import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class EmployeeManagementSystem extends JFrame {
    private JTable employeeTable;
    private DefaultTableModel tableModel;
    private JButton addEmployeeButton;
    private JButton deleteEmployeeButton;
    private JButton editEmployeeButton;
    private JButton addQualificationButton;
    private JButton addPayrollButton;

    public EmployeeManagementSystem() {
        super("Employee Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);

        // Create a table model with column names
        tableModel = new DefaultTableModel();
        tableModel.addColumn("ID");
        tableModel.addColumn("First Name");
        tableModel.addColumn("Last Name");
        tableModel.addColumn("Gender");
        tableModel.addColumn("Age");
        tableModel.addColumn("Address");
        tableModel.addColumn("Email");
        tableModel.addColumn("Password");

        // Create a JTable with the table model
        employeeTable = new JTable(tableModel);

        // Create a JScrollPane to hold the JTable
        JScrollPane scrollPane = new JScrollPane(employeeTable);

        // Create buttons for adding, deleting, and editing employees
        addEmployeeButton = new JButton("Add Employee");
        deleteEmployeeButton = new JButton("Delete Employee");
        editEmployeeButton = new JButton("Edit Employee");
        addQualificationButton = new JButton("Add Qualification");
        addPayrollButton = new JButton("Add Payroll");

        // Add action listeners to the buttons
        addEmployeeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addEmployee();
                viewEmployees();
            }
        });

        deleteEmployeeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteEmployee();
                viewEmployees();
            }
        });

        editEmployeeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                editEmployee();
                viewEmployees();
            }
        });

        addQualificationButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addQualification();
            }
        });

        addPayrollButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addPayroll();
            }
        });

        // Create a panel to hold the buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addEmployeeButton);
        buttonPanel.add(deleteEmployeeButton);
        buttonPanel.add(editEmployeeButton);
        buttonPanel.add(addQualificationButton);
        buttonPanel.add(addPayrollButton);

        // Set the layout of the JFrame and add the components
        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        // Set the JFrame visible
        setVisible(true);

        // Initialize the database connection and view all employees
        initializeDatabase();
        viewEmployees();
    }

    // Method to initialize the database connection
    private void initializeDatabase() {
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Create a database connection
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/EMS", "root", "ilovenisha");

            // Create the necessary tables if they don't exist
            Statement statement = connection.createStatement();
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS Employee (emp_id INT PRIMARY KEY, fname VARCHAR(255) NOT NULL, lname VARCHAR(255) NOT NULL, gender ENUM('Male', 'Female'), age INT, contact_address VARCHAR(255), emp_email VARCHAR(255) NOT NULL, emp_pass VARCHAR(255) NOT NULL)");
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS Qualification (qual_id INT PRIMARY KEY, emp_id INT, position VARCHAR(30), requirements VARCHAR(255), date_in DATE, FOREIGN KEY (emp_id) REFERENCES Employee(emp_id))");
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS Payroll (payroll_id INT PRIMARY KEY, emp_id INT, salary FLOAT(10, 2), FOREIGN KEY (emp_id) REFERENCES Employee(emp_id))");

            // Close the statement and connection
            statement.close();
            connection.close();

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to view all employees in the database
    private void viewEmployees() {
        try {
            // Clear the table model
            tableModel.setRowCount(0);

            // Create a database connection
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/EMS", "root", "ilovenisha");

            // Create a statement and execute the query
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM Employee");

            // Add the results to the table model
            while (resultSet.next()) {
                Object[] row = new Object[8];
                row[0] = resultSet.getInt("emp_id");
                row[1] = resultSet.getString("fname");
                row[2] = resultSet.getString("lname");
                row[3] = resultSet.getString("gender");
                row[4] = resultSet.getInt("age");
                row[5] = resultSet.getString("contact_address");
                row[6] = resultSet.getString("emp_email");
                row[7] = resultSet.getString("emp_pass");
                tableModel.addRow(row);
            }

            // Close the result set, statement, and connection
            resultSet.close();
            statement.close();
            connection.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to add an employee to the database
    private void addEmployee() {
        // Get employee details from UI
        int empId = Integer.parseInt(JOptionPane.showInputDialog(this, "Enter Employee ID:"));
        String firstName = JOptionPane.showInputDialog(this, "Enter First Name:");
        String lastName = JOptionPane.showInputDialog(this, "Enter Last Name:");
        String gender = JOptionPane.showInputDialog(this, "Enter Gender:");
        int age = Integer.parseInt(JOptionPane.showInputDialog(this, "Enter Age:"));
        String address = JOptionPane.showInputDialog(this, "Enter Address:");
        String email = JOptionPane.showInputDialog(this, "Enter Email:");
        String password = JOptionPane.showInputDialog(this, "Enter Password:");

        try {
            // Create a database connection
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/EMS", "root", "ilovenisha");

            // Create a prepared statement for the insert query
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "INSERT INTO Employee (emp_id, fname, lname, gender, age, contact_address, emp_email, emp_pass) " +
                            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
            );

            // Set the parameters of the prepared statement
            preparedStatement.setInt(1, empId);
            preparedStatement.setString(2, firstName);
            preparedStatement.setString(3, lastName);
            preparedStatement.setString(4, gender);
            preparedStatement.setInt(5, age);
            preparedStatement.setString(6, address);
            preparedStatement.setString(7, email);
            preparedStatement.setString(8, password);

            // Execute the prepared statement
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Employee added successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Failed to add employee.");
            }

            // Close the prepared statement and connection
            preparedStatement.close();
            connection.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to delete an employee from the database
    private void deleteEmployee() {
        // Get the selected row index from the table
        int selectedRowIndex = employeeTable.getSelectedRow();

        // Check if a row is selected
        if (selectedRowIndex >= 0) {
            // Get the employee ID from the selected row
            int empId = (int) employeeTable.getValueAt(selectedRowIndex, 0);

            try {
                // Create a database connection
                Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/EMS", "root", "ilovenisha");

                // Create a prepared statement for the delete query
                PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM Employee WHERE emp_id = ?");

                // Set the parameter of the prepared statement
                preparedStatement.setInt(1, empId);

                // Execute the prepared statement
                int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Employee deleted successfully!");
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to delete employee.");
                }

                // Close the prepared statement and connection
                preparedStatement.close();
                connection.close();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(this, "No employee selected.");
        }
    }

    // Method to edit an employee in the database
    private void editEmployee() {
        // Get the selected row index from the table
        int selectedRowIndex = employeeTable.getSelectedRow();

        // Check if a row is selected
        if (selectedRowIndex >= 0) {
            // Get the employee ID from the selected row
            int empId = (int) employeeTable.getValueAt(selectedRowIndex, 0);

            // Get employee details from UI
            String firstName = JOptionPane.showInputDialog(this, "Enter First Name:");
            String lastName = JOptionPane.showInputDialog(this, "Enter Last Name:");
            String gender = JOptionPane.showInputDialog(this, "Enter Gender:");
            int age = Integer.parseInt(JOptionPane.showInputDialog(this, "Enter Age:"));
            String address = JOptionPane.showInputDialog(this, "Enter Address:");
            String email = JOptionPane.showInputDialog(this, "Enter Email:");
            String password = JOptionPane.showInputDialog(this, "Enter Password:");

            try {
                // Create a database connection
                Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/EMS", "root", "ilovenisha");

                // Create a prepared statement for the update query
                PreparedStatement preparedStatement = connection.prepareStatement(
                        "UPDATE Employee SET fname = ?, lname = ?, gender = ?, age = ?, contact_address = ?, emp_email = ?, emp_pass = ? WHERE emp_id = ?"
                );

                // Set the parameters of the prepared statement
                preparedStatement.setString(1, firstName);
                preparedStatement.setString(2, lastName);
                preparedStatement.setString(3, gender);
                preparedStatement.setInt(4, age);
                preparedStatement.setString(5, address);
                preparedStatement.setString(6, email);
                preparedStatement.setString(7, password);
                preparedStatement.setInt(8, empId);

                // Execute the prepared statement
                int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Employee updated successfully!");
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to update employee.");
                }

                // Close the prepared statement and connection
                preparedStatement.close();
                connection.close();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(this, "No employee selected.");
        }
    }

    // Method to add qualification for an employee
    private void addQualification() {
        // Get the selected row index from the table
        int selectedRowIndex = employeeTable.getSelectedRow();

        // Check if a row is selected
        if (selectedRowIndex >= 0) {
            // Get the employee ID from the selected row
            int empId = (int) employeeTable.getValueAt(selectedRowIndex, 0);

            // Get qualification details from UI
            int qualId = Integer.parseInt(JOptionPane.showInputDialog(this, "Enter Qualification ID:"));
            String position = JOptionPane.showInputDialog(this, "Enter Position:");
            String requirements = JOptionPane.showInputDialog(this, "Enter Requirements:");
            String dateIn = JOptionPane.showInputDialog(this, "Enter Date In (YYYY-MM-DD):");

            try {
                // Create a database connection
                Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/EMS", "root", "ilovenisha");

                // Create a prepared statement for the insert query
                PreparedStatement preparedStatement = connection.prepareStatement(
                        "INSERT INTO Qualification (qual_id, emp_id, position, requirements, date_in) " +
                                "VALUES (?, ?, ?, ?, ?)"
                );

                // Set the parameters of the prepared statement
                preparedStatement.setInt(1, qualId);
                preparedStatement.setInt(2, empId);
                preparedStatement.setString(3, position);
                preparedStatement.setString(4, requirements);
                preparedStatement.setDate(5, Date.valueOf(dateIn));

                // Execute the prepared statement
                int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Qualification added successfully!");
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to add qualification.");
                }

                // Close the prepared statement and connection
                preparedStatement.close();
                connection.close();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(this, "No employee selected.");
        }
    }

    // Method to add payroll for an employee
    private void addPayroll() {
        // Get the selected row index from the table
        int selectedRowIndex = employeeTable.getSelectedRow();

        // Check if a row is selected
        if (selectedRowIndex >= 0) {
            // Get the employee ID from the selected row
            int empId = (int) employeeTable.getValueAt(selectedRowIndex, 0);

            // Get payroll details from UI
            int payrollId = Integer.parseInt(JOptionPane.showInputDialog(this, "Enter Payroll ID:"));
            float salary = Float.parseFloat(JOptionPane.showInputDialog(this, "Enter Salary:"));

            try {
                // Create a database connection
                Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/EMS", "root", "ilovenisha");

                // Create a prepared statement for the insert query
                PreparedStatement preparedStatement = connection.prepareStatement(
                        "INSERT INTO Payroll (payroll_id, emp_id, salary) " +
                                "VALUES (?, ?, ?)"
                );

                // Set the parameters of the prepared statement
                preparedStatement.setInt(1, payrollId);
                preparedStatement.setInt(2, empId);
                preparedStatement.setFloat(3, salary);

                // Execute the prepared statement
                int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Payroll added successfully!");
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to add payroll.");
                }

                // Close the prepared statement and connection
                preparedStatement.close();
                connection.close();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(this, "No employee selected.");
        }
    }

    public static void main(String[] args) {
        new EmployeeManagementSystem();
    }
}